GOOGLE COLAB SETUP INSTRUCTIONS
================================

1. Go to: https://colab.research.google.com
2. Create new notebook
3. Enable GPU: Runtime -> Change runtime type -> T4 GPU
4. Upload all files from this package
5. Upload your dataset ZIP file (opportunity+activity+recognition.zip)
6. Run: !python train_activity_colab.py

Expected training time: 1-2 hours

For detailed instructions, see the implementation_plan.md
